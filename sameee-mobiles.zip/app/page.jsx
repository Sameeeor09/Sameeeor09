import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { PhoneIcon } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const phoneListings = [
  {
    id: 1,
    brand: "Samsung",
    model: "Galaxy A12",
    ram: "4GB",
    storage: "64GB",
    condition: "Good",
    repaired: "No",
    price: 6999,
    image: "https://via.placeholder.com/150",
    listedAt: "2024-04-10"
  },
  {
    id: 2,
    brand: "Redmi",
    model: "Note 9",
    ram: "6GB",
    storage: "128GB",
    condition: "Very Good",
    repaired: "Screen replaced",
    price: 8999,
    image: "https://via.placeholder.com/150",
    listedAt: "2024-04-08"
  },
  {
    id: 3,
    brand: "Realme",
    model: "C15",
    ram: "3GB",
    storage: "32GB",
    condition: "Average",
    repaired: "Battery replaced",
    price: 5499,
    image: "https://via.placeholder.com/150",
    listedAt: "2024-04-12"
  }
];

export default function HomePage() {
  const [ramFilter, setRamFilter] = useState("");
  const [budgetFilter, setBudgetFilter] = useState("");
  const [brandFilter, setBrandFilter] = useState("");
  const [sortedByTime, setSortedByTime] = useState(false);

  const filteredPhones = phoneListings
    .filter((phone) => {
      return (
        (ramFilter ? phone.ram === ramFilter : true) &&
        (brandFilter ? phone.brand === brandFilter : true) &&
        (budgetFilter ? phone.price <= parseInt(budgetFilter) : true)
      );
    })
    .sort((a, b) => {
      if (!sortedByTime) return 0;
      return new Date(b.listedAt).getTime() - new Date(a.listedAt).getTime();
    });

  return (
    <div className="p-6 space-y-10">
      {/* Hero Section */}
      <section className="text-center space-y-4">
        <h1 className="text-4xl font-bold text-blue-600">Sameee Second Hand Mobile</h1>
        <p className="text-gray-600">Buy & Sell Used Phones in Mahwa, District Dausa - 321608</p>
        <Button className="mt-4" variant="default">Contact via WhatsApp</Button>
      </section>

      {/* Filters */}
      <section className="flex flex-col sm:flex-row flex-wrap gap-4 justify-center items-center">
        <Select onValueChange={setBrandFilter}>
          <SelectTrigger className="w-40">
            <SelectValue placeholder="Filter by Brand" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="Samsung">Samsung</SelectItem>
            <SelectItem value="Redmi">Redmi</SelectItem>
            <SelectItem value="Realme">Realme</SelectItem>
          </SelectContent>
        </Select>

        <Select onValueChange={setRamFilter}>
          <SelectTrigger className="w-40">
            <SelectValue placeholder="Filter by RAM" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="3GB">3GB</SelectItem>
            <SelectItem value="4GB">4GB</SelectItem>
            <SelectItem value="6GB">6GB</SelectItem>
          </SelectContent>
        </Select>

        <Input
          type="number"
          placeholder="Max Budget (₹)"
          className="w-40"
          onChange={(e) => setBudgetFilter(e.target.value)}
        />

        <Button onClick={() => setSortedByTime(!sortedByTime)}>
          {sortedByTime ? "Sorted by Newest" : "Sort by Listing Time"}
        </Button>
      </section>

      {/* Phone Listings */}
      <section>
        <h2 className="text-2xl font-semibold mb-4">Available Phones</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredPhones.map((phone) => (
            <Card key={phone.id} className="rounded-2xl shadow-md">
              <CardContent className="p-4">
                <img src={phone.image} alt="Phone" className="w-full h-40 object-cover rounded-md mb-2" />
                <h3 className="text-lg font-bold">{phone.brand} {phone.model}</h3>
                <p className="text-sm text-gray-500">{phone.ram} RAM / {phone.storage} Storage</p>
                <p className="text-sm text-gray-500">Condition: {phone.condition} | {phone.repaired}</p>
                <p className="text-sm text-gray-400">Listed: {phone.listedAt}</p>
                <p className="text-xl font-semibold text-green-600 mt-2">₹{phone.price}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>
    </div>
  );
}
